"""
Your module description
"""
print("A: {}, B: {}, c; {}".format(1, 2, 3))
print(f"A: %s, B: %s, c; %s" %(1, 2, 3))

print()

fruit = {
    "Apple" : "Green",
    "Orange" : "Orange",
    "Lemon" : "Yellow"
}

print(fruit)
print(fruit["Apple"])

print()

myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]

for item in myMixedTypeList:
    print("{} is of data type {}".format(item, type(item)))
    
print()

